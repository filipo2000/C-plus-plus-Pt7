#pragma once
#ifndef TSum_h
#define TShum_h

#include <vector>
#include <list>
#include <map>

using namespace std; //Don't foreget this or use std::

//Objective -> In this file we declare our Sum function variants

//Vector and Lists will use the same Sum functions -> map needs it's own version since it's element structure is different -> has a key + value as an element


//Function 1
template <typename T> 
double Sum(const T& c);


template <typename T, typename X> 
double Sum(const map<T,X>& s);


//Function 3
template <class T> //Iterators that iterate over a STL container are of that container type
double Sum(typename T::const_iterator& begin , typename T::const_iterator& end); //typename keyword is necessary since iterators are dependent -> their types rely on the STL container they iterate over

template <typename T1, typename T2> 
double Sum(typename const map<T1, T2>::const_iterator &a, typename const map<T1,T2>::const_iterator &b);





//When dealing with templates we need to include this

#ifndef TSum_cpp
#include "TSum.cpp"
#endif




#endif