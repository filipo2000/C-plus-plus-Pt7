#include <vector>
#include <list>
#include <map>
#include <iostream>
using namespace std;

#include "TSum.h"

//Objective -> In this file we create a function which calculates the sum of elements within a STL container

//Every test works fine


int main() {
	
	//Appplying Sum() template function variants on out list STL container
	list<double> a = { 2.3, 4.4, 9.1 }; //Our list of doubles
	
	//Regular Version -> List provided as argument
	std::cout << Sum<list<double>>(a) << std::endl; //Works perfectly prints out 15.8 
	
	//Iterator Version
	list<double>::const_iterator s1 = a.begin();
	list<double>::const_iterator s2 = a.end();
	std::cout << Sum<list<double>>(s1, s2) << std::endl; //Iterator version -> Works perfectly

	
	//Appplying Sum() template function variants on out vector STL container
	vector<double> b = { 8.4, 3.5, 4.6 };
	
	//Regular Version -> Vector provided as argument
	std::cout << Sum<vector<double>>(b) << std::endl; //Works perfectly prints out
	
	//Iterator Version 
	vector<double>::const_iterator v1 = b.begin();
	vector<double>::const_iterator v2 = b.end();
	std::cout << Sum<vector<double>>(v1, v2) << std::endl; //Iterator version on vector works perfectly

	//Appplying Sum() template function variants on out map STL container
	map<string, double> c; //We can't just add pairs to the map when declaring and initlizaing a map container
	c["Jerry"] = 39.2; 
	c["Mike"] = 42.2;
	c["Drew"] = 21.1;

	//Regular Version 
	std::cout << Sum<string,double>(c) << std::endl; //Works fine now -> 102.5 //inside the <> brackets go types for the template arguments -> inside the () goes the argument for the Sum() function variant
	
	//Iterator Version
	std::cout << Sum<string, double>(c.begin(), c.end()) << std::endl; //Works perfectly -> 102.5 gets outputted -> Iterator version()

	
}







