#ifndef TSum_cpp
#define TSum_cpp

#include "TSum.h"

//Objective -> In this file we define our Sum function variants


template <typename T>
double Sum(const T& c) { //T denotes the container type -> T will be either vector or list in our case depending on the argument provided when calling this function
	
	double sum = 0.0;
	typename T::const_iterator a = c.begin(); //typename keyword must be used since it's dependent on type T
	typename T::const_iterator b = c.end();

	for (a; a != b; a++) {
		sum = sum + (*a);
	}

	return sum;

}



//1st parameter is for the starting iterator -> 2nd parameter is for the ending iterator
template <typename T> //Template argument is for the iterator type
double Sum(typename T::const_iterator& begin, typename T::const_iterator& end) { //Iterators are of a container type hence of type T -> aka an iterator that iterates over a vector is of type vector etc.

	double sum = 0.0;
	
	//Using the iterator reference parameters which refer to the iterators provided as arguments
	for (begin; begin != end; begin++) {
		sum = sum + (*begin); //fetch the value component of each key value pair
	}


	return sum;

}



//Sum() variants for map STL containers we need 2 arguments for the template since each element of a map consists of 2 components 
template <typename T, typename X>
double Sum(const map<T, X>& a) { //Since a map contains 2 types one type for the key and another for the value we need 2 arguments when constructing a map STL container object hence 2 arguments are needed for a template function that contain a map STL container as an parameter
	
	double sum = 0;
	typename map<T, X>::const_iterator b1 = a.begin(); //Our const_iterators b1 and e1 are of type map<T,X> and not const map <T,X>
	typename map<T, X>::const_iterator e1 = a.end();

	for (b1; b1 != e1; b1++) {
		sum = sum + b1->second;
	}

	return sum;

}



template <typename X, typename Y> //Arguements for a template are just placeholders for types -> int, string etc.
double Sum(typename const map<X, Y>::const_iterator& a, typename const map<X, Y>::const_iterator& b) {
	
	double sum = 0.0;
	
	typename map<X,Y>::const_iterator z;
	
	for (z = a; z != b; z++) {
		sum = sum + z->second;
	}

	return sum;

}




#endif