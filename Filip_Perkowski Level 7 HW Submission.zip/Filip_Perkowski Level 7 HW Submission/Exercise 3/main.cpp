//The majority  of algorithms/functions that we are looking to work with on iterators of STL containers are in the algorithm header. Basic algorithm/functions are defined in the container template class alongside the iterator type that the container supports etc.
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

//Creating a class with a () operator function -> Functors are essentially callable classes and objects
class Test {
private:
	double num;
public:
	Test(double p):num(p) {}; //Parameter constructor
	~Test(){}; //Destructor -> To terminate our Test object a -> Called when a goes out of it's scope in which it was created
	bool operator()(double a) { //Double a will be each element within the STL container in this case vector vec
		return (a < num);
	}
	double At() {
		return num;
	}
};


//Our Public Function
bool Less(double a) { //when implementing this as an argument in the count_if function() -> a the parameter becomes each element in the container vec thanks to help of begin() iterator which iterates through the elements in vector vec until the it equals iterator end()
	return a < 5.0; //Any literal value

}


int main() {
	//Functions outside a class can acess public members -> Public members cannot fetch use anything that's outside the class inside it's body
	//We must use a class object to acess a our public functions. We must use public functions within a class to acess private member of a class 
	//I'll use the vector STL container for this exercise
	
	std::vector<double> vec = { 3.2, 6.0, 3.1, 9.3, 8.9 };
	
	
	//Part 1 -> Using a Public template function as an argument in count_if
	int temp = count_if(vec.begin(), vec.end(), Less);
	std::cout << "In vector vec: " << temp << " numbers are less that 5.0" << std::endl;


	Test a(6.2); //Creating our Test class object a using the parameter constructor
	
	//Part 2 -> Using a functor as an argument in count_if
	int resi = std::count_if(vec.begin(), vec.end(), a); //Dont' forget to use to use the std namespace -> a(3.2) is our functor we are putting parenthese on class object a -> what's happening here is we are calling the () operator function in class Cnt
	std::cout << "In vector vec: " << resi << " numbers are less than " << a.At() << std::endl; //Value to check is 4.0
	
	




}