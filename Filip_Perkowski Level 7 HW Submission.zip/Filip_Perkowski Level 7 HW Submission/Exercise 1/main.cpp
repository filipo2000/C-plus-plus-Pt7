//We must include the appropriate header files to use the appropriate container types offered in STL
//A buffer is memory of a fixed size -> Usually for multiple variables/elements of a container etc. -> Memory a
//How containers are stored in memory -> Elements within a container have their own place in memory; The container itself/as a whole also has it's own place in memory. Arrays are exception as an array when used converts itself to the first element within the array -> This is a special property which the array posseses
//Contigous Memory -> This means that the elements of a container are stored next to each other in memory
//With standard arrays(arrays elements are stored on the stack) we must first make on for ex: int a[10] and then set a pointer to it -> int* p = &a;
//With a dynamic array(arrays elements are stored on the heap) we use the new key word directly so that a pointer is assigned and a array is created/allocated in heap memory at the same time -> int* ptr = new int[10]
//Pointers that points to elements of an array or any other container, have additional properties. For instance we can increment the pointer so that it points to the next element -> We can index a pointer to fetch a given element in the container
//Speaking of the above -> ptr[i] is the same as *(ptr + i) where ptr is a pointer
//using the begin() and end() function on a STL container return being and ending iterators on that container respectively
#include <iostream>
#include <list> 
#include <vector>
#include <map>
using namespace std;

//Objective -> Here we practice using different STL containers from the Standard Template Library and use them

//List of double -> Where a list is a container type from the standard template library
//Remember that in the Standard Template library it's class templates that denote the container types hence when defining a container we must do so in template form so that the class template invokes the proper template class -> In this case object a is of type list<double>


int main() {
	
	
	//Part 1
	
	list<double> a = { 2.3, 4.4, 9.1 }; //Our list of doubles
	std::cout << "The first element is List A is: " << a.front() << std::endl;
	std::cout << "The last element is List A is: " << a.back() << std::endl;


	//Part 2
	
	vector<double> b = {8.4, 2.5, 4.6};
	//Acessing the 0th index/ 1st element
	std::cout << "The first element in our vector is: " << b[0] << std::endl;
	std::cout << "The last element in our vector pre-growth is: " << b[2] << std::endl;

	//Growing/Increasing the size of our vector -> We can't grow/increase the size of a vector using the [] operator hence we must use functions supported by the vector template class
	//Adding 2 additional elements ->Growing
	b.push_back(1.0);
	b.push_back(3.2);

	//Checking if the vector grew:
	std::cout << "The last element in vector b post-growth is: " << b[4] << std::endl; //b.back() works

	
	//Part 3
	
	//Maps holds key-value pairs -> Maps in C++ are like dictionaries in Python
	//Derefrence iterator and then acess these function aka use the -> ;Using the first() function on iterator which works on a map gives us the key of the element/pair that the iterator reffers to in the map; Using the second() function on an iterator gives us the value part of the element/key-value pair that the iterator reffers to in the map
	map<string, double> c = {}; //We can't just add pairs to the map when declaring and initlizaing a map container
	//We should use the insert() and make_pair() functions
	c.insert(make_pair("Jerry", 39.2)); //c[name of key] = value is an alternative way we could add key-value pairs/elements to our map
	c.insert(make_pair("Mike", 43.2));
	c.insert(make_pair("Drew", 21.1));

	std::cout << c["Jerry"] << std::endl; //In the case of map containers, the value in the [] operator is the key not the index
	std::cout << c["Mike"] << std::endl;
	std::cout << c["Drew"] << std::endl;

}
 

